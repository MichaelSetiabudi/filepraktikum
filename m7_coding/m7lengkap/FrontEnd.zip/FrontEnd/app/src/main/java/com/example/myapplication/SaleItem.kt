package com.example.myapplication

data class SaleItem(
    val id_produk: String,
    val quantity: Int
)