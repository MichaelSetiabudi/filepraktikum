package com.example.myapplication

data class Customer(
    val id_customer: String? = null,
    val nama_customer: String
)