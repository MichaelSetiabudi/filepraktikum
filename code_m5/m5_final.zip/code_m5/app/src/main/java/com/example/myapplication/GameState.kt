package com.example.myapplication

class GameState {
    companion object {
        const val PLAYING = "PLAYING"
        const val BOSS_FIGHT = "BOSS_FIGHT"
    }
}