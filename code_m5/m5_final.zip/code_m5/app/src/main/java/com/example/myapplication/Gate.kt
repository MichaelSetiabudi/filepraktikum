package com.example.myapplication

data class Gate(
    val value: Int,
    val operator: String,
    var column: Int
)